package ss.week1;

/**
 * Created by willem on 16-11-16.
 */
public class Lamp {
    private int setting = 0;

    public String getSetting() {
        switch (this.setting) {
            case 0:
                return "Off";
            case 1:
                return "Low";
            case 2:
                return "Medium";
            case 3:
                return "High";
        }
        return "Error; Setting not in bounds";
    }

    public void setSetting(int newSetting) {
        this.setting = newSetting;
    }

    public void setOff(){
        setting = 0;
    }

    public void setLow () {
        setting = 1;
    }

    public void setMedium () {
        setting = 2;
    }

    public void setHigh() {
        setting = 3;
    }
}
