package ss.week1.hotel;

/**
 * Class guest for a hotel system
 * @author Jesper & Willem
 * @version 1.0.0
 */
public class Guest extends java.lang.Object{
    private String name;
    private Room room;
    /**Guest is constructed and given the name inputed*/
    public Guest (java.lang.String name){
        this.name = name;
    }

    /**
     * Checkin returns False if the checkin isnt succesfull, and True if the checkin was succesfull
     */
    public boolean checkin(Room r){
        if(this.room != null || r.getGuest() != null){
            return false;
        }else{
            room = r;
            r.setGuest(this);
            return true;
        }
    }

    /**
     * checkout returns true if the checkout was succesful otherwise it retuns false
     */
    public boolean checkout() {
        if(this.room != null){
            room.setGuest(null);
            room = null;
            return true;
        }else{
            return false;
        }
    }

    /**
     * returns name of guest
     */
    public java.lang.String getName(){
        return name;
    }

    /**
     * returns room of the guest, null if there is no room
     */
    public Room getRoom(){
        return room;
    }

    public java.lang.String toString(){
        String description;
        description = "Guest ";
        description += name;
        if (room != null) {
            description += " resides in " + room.getNumber();
        }else{
            description += " Has not yet checked in to a room";
        }
        description += ".";
        return description;
    }
}
