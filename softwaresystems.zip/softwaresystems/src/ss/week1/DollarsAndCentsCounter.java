package ss.week1;

/**
 * Created by willem on 16-11-16.
 */
public class DollarsAndCentsCounter {
    private int dollarCount;
    private int centCounter;

    public int dollars() {
        if(this.dollarCount < 0) {
            System.out.println("Error; Dollars can't be less than 0");
            this.dollarCount = 0;
        }
        return this.dollarCount;
    }

    public int cents() {
        if(this.centCounter < 0){
            if(this.dollarCount > 0){
                this.dollarCount -= 1;
                this.centCounter += 100;
            }else{
                this.centCounter = 0;
                System.out.println("Error; Cannot decrease dollarCount further than 0");
            }
        }else if(this.centCounter > 99) {
            this.centCounter -= 100;
            this.dollarCount += 1;
        }
        return this.centCounter;
    }

    public void add (int dollars, int cents){
        this.dollarCount += dollars;
        this.centCounter += cents;
    }

    public void substract (int dollars, int cents){
        if (this.dollarCount < dollars || (this.dollarCount == dollars && this.centCounter < cents)){
            System.out.println("Error; Cannot substract more than original funds");
        }else{
            this.dollarCount -= dollars;
            this.centCounter -= cents;
            if(this.centCounter < 0){
                this.dollarCount -= 1;
                this.centCounter += 100;
            }
        }
    }

    public void reset () {
        this.dollarCount = 0;
        this.centCounter = 0;
    }
}
